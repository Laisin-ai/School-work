/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author BRIGITTE-LAURE
 */


public class Professor {
	
	 private String name;

	    public Professor(String name) {
	        this.name = name;
	    }

	    public String getName() {
	        return this.name;
	    }
}

    

